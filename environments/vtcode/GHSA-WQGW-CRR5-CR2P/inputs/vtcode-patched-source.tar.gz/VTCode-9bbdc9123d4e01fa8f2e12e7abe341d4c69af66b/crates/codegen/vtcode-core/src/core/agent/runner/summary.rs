use super::AgentRunner;
use crate::core::agent::task::{Task, TaskOutcome};
use crate::llm::provider::{Message, MessageRole};

impl AgentRunner {
    /// Generate a meaningful summary of the task execution
    #[expect(
        clippy::too_many_arguments,
        reason = "Intentional compatibility, platform, test, or API-shape suppression."
    )]
    pub(super) fn generate_task_summary(
        &self,
        task: &Task,
        modified_files: &[String],
        executed_commands: &[String],
        warnings: &[String],
        messages: &[Message],
        turns_executed: usize,
        peak_tool_loops: usize,
        max_tool_loops: usize,
        outcome: TaskOutcome,
        total_duration_ms: u128,
        average_turn_duration_ms: Option<f64>,
        max_turn_duration_ms: Option<u128>,
        total_usage: &vtcode_exec_events::Usage,
    ) -> String {
        let mut summary = Vec::new();

        summary.push(format!("Task: {}", task.title));
        if !task.description.trim().is_empty() {
            summary.push(format!("Description: {}", task.description.trim()));
        }
        summary.push(format!("Agent Type: {:?}", self.agent_type));
        summary.push(format!("Session: {}", self.session_id));

        let reasoning_label = self
            .reasoning_effort
            .map(|effort| effort.to_string())
            .unwrap_or_else(|| "default".to_owned());

        summary.push(format!(
            "Model: {} (provider: {}, reasoning: {})",
            self.client.model_id(),
            self.provider_client.name(),
            reasoning_label
        ));

        let tool_loops_used = peak_tool_loops;
        let max_tool_loops_label = if max_tool_loops == 0 {
            "unlimited".to_owned()
        } else {
            max_tool_loops.to_string()
        };
        summary.push(format!(
            "Turns: {} used / {} max | Tool loops: {} used / {} max",
            turns_executed, self.max_turns, tool_loops_used, max_tool_loops_label
        ));

        let mut duration_line = format!("Duration: {total_duration_ms} ms");
        let mut duration_metrics = Vec::new();
        if let Some(avg) = average_turn_duration_ms {
            duration_metrics.push(format!("avg {avg:.1} ms/turn"));
        }
        if let Some(max_turn) = max_turn_duration_ms {
            duration_metrics.push(format!("max {max_turn} ms"));
        }
        if !duration_metrics.is_empty() {
            duration_line.push_str(" (");
            duration_line.push_str(&duration_metrics.join(", "));
            duration_line.push(')');
        }
        summary.push(duration_line);

        let mut resolved_outcome = outcome;
        if matches!(resolved_outcome, TaskOutcome::Unknown)
            && messages
                .iter()
                .rev()
                .find(|message| message.role == MessageRole::Assistant)
                .is_some_and(|message| {
                    let content = message.content.as_text();
                    content.contains("completed") || content.contains("done") || content.contains("finished")
                })
        {
            resolved_outcome = TaskOutcome::Success;
        }

        let mut status_line = format!("Final Status: {}", resolved_outcome.description());
        if !warnings.is_empty() && resolved_outcome.is_success() {
            status_line.push_str(" (with warnings)");
        }
        summary.push(status_line);
        summary.push(format!("Outcome Code: {}", resolved_outcome.code()));

        if total_usage.input_tokens > 0 {
            summary.push(total_usage.cache_summary());
        }

        if !executed_commands.is_empty() {
            summary.push("Executed Commands:".to_owned());
            for command in executed_commands {
                summary.push(format!(" - {command}"));
            }
        }

        if !modified_files.is_empty() {
            summary.push("Modified Files:".to_owned());
            for file in modified_files {
                summary.push(format!(" - {file}"));
            }
        }

        if !warnings.is_empty() {
            summary.push("Warnings:".to_owned());
            for warning in warnings {
                summary.push(format!(" - {warning}"));
            }
        }

        summary.join("\n")
    }
}
