pub const DEFAULT_MODEL: &str = GLM_5_3;
pub const SUPPORTED_MODELS: &[&str] = &[GLM_5_3, GLM_5_2, GLM_5_1, GLM_47];

pub(crate) const REASONING_MODELS: &[&str] = &[GLM_5_3, GLM_5_2, GLM_5_1, GLM_47];

pub const GLM_5_1: &str = "glm-5.1";
pub(crate) const GLM_5_2: &str = "glm-5.2";
pub const GLM_5_3: &str = "glm-5.3";
const GLM_47: &str = "glm-4.7";
