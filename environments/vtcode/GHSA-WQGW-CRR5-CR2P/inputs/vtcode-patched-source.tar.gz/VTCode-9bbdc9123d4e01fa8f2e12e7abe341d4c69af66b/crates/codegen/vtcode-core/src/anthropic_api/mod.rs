//! Anthropic API compatibility layer for VT Code
//!
//! Provides compatibility with the Anthropic Messages API to help connect existing
//! applications to VT Code, including tools like Claude Code.

#[cfg(feature = "anthropic-api")]
pub use crate::llm::providers::anthropic::api as server;
