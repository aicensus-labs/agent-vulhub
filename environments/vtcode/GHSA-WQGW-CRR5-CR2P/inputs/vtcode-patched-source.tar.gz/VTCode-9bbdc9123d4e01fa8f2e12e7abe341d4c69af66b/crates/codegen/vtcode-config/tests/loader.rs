#![allow(
    missing_docs,
    reason = "Intentional compatibility, platform, or test-only suppression."
)]
use anyhow::Result;
use assert_fs::TempDir;
use serial_test::serial;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use vtcode_commons::canonicalize;
use vtcode_commons::paths::WorkspacePaths;
use vtcode_config::ConfigLayerSource;
use vtcode_config::ConfigManager;
use vtcode_config::constants::defaults;
use vtcode_config::defaults::provider::with_config_defaults_provider_for_test;
use vtcode_config::defaults::{ConfigDefaultsProvider, WorkspacePathsDefaults};

#[derive(Clone)]
struct TestPaths {
    root: PathBuf,
    config_dir: PathBuf,
}

impl TestPaths {
    fn new(root: PathBuf, config_dir: PathBuf) -> Self {
        Self { root, config_dir }
    }
}

impl WorkspacePaths for TestPaths {
    fn workspace_root(&self) -> &Path {
        &self.root
    }

    fn config_dir(&self) -> PathBuf {
        self.config_dir.clone()
    }
}

fn with_test_defaults<T>(
    workspace_root: &Path,
    config_dir: PathBuf,
    home_paths: Vec<PathBuf>,
    action: impl FnOnce() -> T,
) -> T {
    let workspace_paths = TestPaths::new(workspace_root.to_path_buf(), config_dir);
    let provider = WorkspacePathsDefaults::new(Arc::new(workspace_paths))
        .with_home_paths(home_paths)
        .build();
    let provider: Arc<dyn ConfigDefaultsProvider> = provider.into();

    with_config_defaults_provider_for_test(provider, action)
}

fn write_config(path: &Path, provider: &str) -> Result<()> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }

    let contents = format!("[agent]\nprovider = \"{provider}\"\nmax_conversation_turns = 5\n");
    fs::write(path, contents)?;
    Ok(())
}

#[test]
#[serial]
fn loads_config_from_workspace_root_before_config_dir() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    let root_config = workspace_root.join("vtcode.toml");
    let config_dir_config = config_dir.join("vtcode.toml");
    let home_config = workspace_root.join("home").join("vtcode.toml");

    write_config(&root_config, "workspace-root")?;
    write_config(&config_dir_config, "config-dir")?;
    write_config(&home_config, "home")?;

    let manager = with_test_defaults(workspace_root, config_dir, vec![home_config.clone()], || {
        ConfigManager::load_from_workspace(workspace_root)
    })?;
    let expected_root_config = canonicalize(&root_config)?;

    assert_eq!(manager.config().agent.provider, "workspace-root");
    assert_eq!(manager.config_path(), Some(expected_root_config.as_path()));

    Ok(())
}

#[test]
#[serial]
fn loads_config_from_config_dir_when_root_missing() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    let config_dir_config = config_dir.join("vtcode.toml");
    let home_config = workspace_root.join("home").join("vtcode.toml");

    write_config(&config_dir_config, "config-dir")?;
    write_config(&home_config, "home")?;

    let manager = with_test_defaults(workspace_root, config_dir, vec![home_config.clone()], || {
        ConfigManager::load_from_workspace(workspace_root)
    })?;
    let expected_config_dir_config = canonicalize(&config_dir_config)?;

    assert_eq!(manager.config().agent.provider, "config-dir");
    assert_eq!(manager.config_path(), Some(expected_config_dir_config.as_path()));

    Ok(())
}

#[test]
#[serial]
fn loads_config_from_home_directory_when_workspace_missing() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    let home_config = workspace_root.join("home").join("vtcode.toml");
    write_config(&home_config, "home")?;

    let manager = with_test_defaults(workspace_root, config_dir, vec![home_config.clone()], || {
        ConfigManager::load_from_workspace(workspace_root)
    })?;
    let expected_home_config = canonicalize(&home_config)?;

    assert_eq!(manager.config().agent.provider, "home");
    assert_eq!(manager.config_path(), Some(expected_home_config.as_path()));

    Ok(())
}

#[test]
#[serial]
fn falls_back_to_default_config_when_no_files_found() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    let manager = with_test_defaults(workspace_root, config_dir, Vec::new(), || {
        ConfigManager::load_from_workspace(workspace_root)
    })?;

    assert!(manager.config_path().is_none());
    assert_eq!(manager.config().agent.provider, defaults::DEFAULT_PROVIDER);

    Ok(())
}

#[test]
#[serial]
fn load_uses_current_directory_workspace() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    let root_config = workspace_root.join("vtcode.toml");
    write_config(&root_config, "workspace-root")?;

    let original_dir = std::env::current_dir()?;
    std::env::set_current_dir(workspace_root)?;

    let manager = with_test_defaults(workspace_root, config_dir, Vec::new(), ConfigManager::load);

    std::env::set_current_dir(original_dir)?;

    let manager = manager?;
    let expected_root_config = canonicalize(&root_config)?;
    assert_eq!(manager.config().agent.provider, "workspace-root");
    assert_eq!(manager.config_path(), Some(expected_root_config.as_path()));

    Ok(())
}

#[test]
#[serial]
fn load_canonicalizes_relative_workspace_paths() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    let root_config = workspace_root.join("vtcode.toml");
    write_config(&root_config, "workspace-root")?;

    let original_dir = std::env::current_dir()?;
    std::env::set_current_dir(workspace_root)?;

    let manager = with_test_defaults(workspace_root, config_dir, Vec::new(), || {
        ConfigManager::load_from_workspace(PathBuf::from("."))
    });

    std::env::set_current_dir(original_dir)?;
    let manager = manager?;
    let expected_root_config = canonicalize(&root_config)?;
    let expected_workspace_root = canonicalize(workspace_root)?;

    assert_eq!(manager.config().agent.provider, "workspace-root");
    assert_eq!(manager.config_path(), Some(expected_root_config.as_path()));
    assert_eq!(manager.workspace_root(), Some(expected_workspace_root.as_path()));

    Ok(())
}

#[test]
#[serial]
fn use_root_config_discards_lower_precedence_layers() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    // Home config sets provider to "home"
    let home_config = workspace_root.join("home").join("vtcode.toml");
    write_config(&home_config, "home")?;

    // Workspace root sets use_root_config = true and provider to "root"
    let root_config = workspace_root.join("vtcode.toml");
    fs::write(
        &root_config,
        "[workspace]\nuse_root_config = true\n\n[agent]\nprovider = \"root\"\nmax_conversation_turns = 5\n",
    )?;

    let manager = with_test_defaults(workspace_root, config_dir, vec![home_config], || {
        ConfigManager::load_from_workspace(workspace_root)
    })?;

    // Only workspace root config should apply; home config discarded
    assert_eq!(manager.config().agent.provider, "root");

    // Only workspace root layer (+ any runtime) should remain
    let layers = manager.layer_stack().layers();
    assert!(
        layers
            .iter()
            .all(|l| matches!(&l.source, ConfigLayerSource::Workspace { .. } | ConfigLayerSource::Runtime)),
        "expected only workspace/runtime layers, got: {:?}",
        layers.iter().map(|l| l.source.label()).collect::<Vec<_>>()
    );

    Ok(())
}

#[test]
#[serial]
fn use_root_config_false_preserves_normal_layering() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    let home_config = workspace_root.join("home").join("vtcode.toml");
    write_config(&home_config, "home")?;

    let root_config = workspace_root.join("vtcode.toml");
    fs::write(
        &root_config,
        "[workspace]\nuse_root_config = false\n\n[agent]\nprovider = \"root\"\nmax_conversation_turns = 5\n",
    )?;

    let manager = with_test_defaults(workspace_root, config_dir, vec![home_config], || {
        ConfigManager::load_from_workspace(workspace_root)
    })?;

    // Normal layering: workspace root wins over home
    assert_eq!(manager.config().agent.provider, "root");
    assert!(manager.layer_stack().layers().len() >= 2);

    Ok(())
}

#[test]
#[serial]
fn use_root_config_absent_preserves_normal_layering() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();
    let config_dir = workspace_root.join(".vtcode");
    fs::create_dir_all(&config_dir)?;

    let home_config = workspace_root.join("home").join("vtcode.toml");
    write_config(&home_config, "home")?;

    let root_config = workspace_root.join("vtcode.toml");
    fs::write(&root_config, "[agent]\nprovider = \"root\"\nmax_conversation_turns = 5\n")?;

    let manager = with_test_defaults(workspace_root, config_dir, vec![home_config], || {
        ConfigManager::load_from_workspace(workspace_root)
    })?;

    // Normal layering: workspace root wins over home
    assert_eq!(manager.config().agent.provider, "root");
    assert!(manager.layer_stack().layers().len() >= 2);

    Ok(())
}

#[test]
#[serial]
fn use_root_config_from_file_discards_lower_precedence_layers() -> Result<()> {
    let workspace = TempDir::new()?;
    let workspace_root = workspace.path();

    // Workspace root config with use_root_config = true
    let root_config = workspace_root.join("vtcode.toml");
    fs::write(
        &root_config,
        "[workspace]\nuse_root_config = true\n\n[agent]\nprovider = \"root\"\nmax_conversation_turns = 5\n",
    )?;

    // Load from file directly
    let manager = ConfigManager::load_from_file(&root_config)?;

    assert_eq!(manager.config().agent.provider, "root");

    // Only workspace layer (+ any runtime) should remain; no system/user layers
    let layers = manager.layer_stack().layers();
    assert!(
        layers
            .iter()
            .all(|l| matches!(&l.source, ConfigLayerSource::Workspace { .. } | ConfigLayerSource::Runtime)),
        "expected only workspace/runtime layers, got: {:?}",
        layers.iter().map(|l| l.source.label()).collect::<Vec<_>>()
    );

    Ok(())
}

#[test]
#[serial]
fn providers_whitelist_validation_rejects_unknown_provider() {
    let toml = r#"
providers_whitelist = ["openai", "nonexistent-provider"]

[agent]
provider = "openai"
default_model = "gpt-5"
"#;
    let config: vtcode_config::VTCodeConfig = toml::from_str(toml).unwrap();
    let result = config.validate();
    assert!(result.is_err(), "unknown whitelist entry should fail validation");
    let err_msg = result.unwrap_err().to_string();
    assert!(err_msg.contains("nonexistent-provider"), "error should name the bad entry: {err_msg}");
}

#[test]
#[serial]
fn providers_whitelist_validation_accepts_known_providers() {
    let toml = r#"
providers_whitelist = ["openai", "anthropic", "gemini"]

[agent]
provider = "openai"
default_model = "gpt-5"
"#;
    let config: vtcode_config::VTCodeConfig = toml::from_str(toml).unwrap();
    assert!(config.validate().is_ok(), "known providers should pass validation");
}

#[test]
#[serial]
fn providers_whitelist_validation_accepts_custom_provider_names() {
    let toml = r#"
providers_whitelist = ["mycorp"]

[agent]
provider = "mycorp"
default_model = "gpt-5"

[[custom_providers]]
name = "mycorp"
display_name = "MyCorp"
base_url = "https://api.mycorp.example.com/v1"
"#;
    let config: vtcode_config::VTCodeConfig = toml::from_str(toml).unwrap();
    assert!(config.validate().is_ok(), "custom provider name in whitelist should pass");
}
