use serde_json::Value;

use super::catalog::{SupportedTool, ToolDescriptor};
use super::schemas::{
    TOOL_LIST_FILES_CONTENT_PATTERN_ARG, TOOL_LIST_FILES_NAME_PATTERN_ARG, TOOL_LIST_FILES_PATH_ARG,
    TOOL_READ_FILE_PATH_ARG, TOOL_READ_FILE_URI_ARG,
};
use vtcode_commons::formatting::truncate_middle;
use vtcode_core::tools::registry::labels::tool_action_label;

pub(super) fn render_title(descriptor: ToolDescriptor, function_name: &str, args: &Value) -> String {
    match descriptor {
        ToolDescriptor::Acp(tool) => match tool {
            SupportedTool::ReadFile => args
                .get(TOOL_READ_FILE_PATH_ARG)
                .and_then(Value::as_str)
                .filter(|value| !value.is_empty())
                .map(|path| format!("Read file {}", truncate_middle(path, 80)))
                .or_else(|| {
                    args.get(TOOL_READ_FILE_URI_ARG)
                        .and_then(Value::as_str)
                        .filter(|value| !value.is_empty())
                        .map(|uri| format!("Read file {}", truncate_middle(uri, 80)))
                })
                .unwrap_or_else(|| tool.default_title().to_string()),
            SupportedTool::ListFiles => {
                if let Some(path) = args
                    .get(TOOL_LIST_FILES_PATH_ARG)
                    .and_then(Value::as_str)
                    .filter(|value| !value.is_empty())
                {
                    if path == "." {
                        "List files in workspace root".to_string()
                    } else {
                        format!("List files in {}", truncate_middle(path, 60))
                    }
                } else if let Some(pattern) = args
                    .get(TOOL_LIST_FILES_NAME_PATTERN_ARG)
                    .and_then(Value::as_str)
                    .filter(|value| !value.is_empty())
                {
                    format!("Find files named {}", truncate_middle(pattern, 40))
                } else if let Some(pattern) = args
                    .get(TOOL_LIST_FILES_CONTENT_PATTERN_ARG)
                    .and_then(Value::as_str)
                    .filter(|value| !value.is_empty())
                {
                    format!("Search files for {}", truncate_middle(pattern, 40))
                } else {
                    tool.default_title().to_string()
                }
            }
        },
        ToolDescriptor::Local => tool_action_label(function_name, args).to_string(),
    }
}
