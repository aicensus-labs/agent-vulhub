pub(crate) const SESSION_PREFIX: &str = "vtcode-zed-session";
pub(crate) const RESOURCE_FALLBACK_LABEL: &str = "Resource";
pub(crate) const RESOURCE_FAILURE_LABEL: &str = "Resource unavailable";
pub(crate) const RESOURCE_CONTEXT_OPEN: &str = "<context";
pub(crate) const RESOURCE_CONTEXT_CLOSE: &str = "</context>";
pub(crate) const RESOURCE_CONTEXT_URI_ATTR: &str = "uri";
pub(crate) const RESOURCE_CONTEXT_NAME_ATTR: &str = "name";
pub(crate) const MAX_TOOL_RESPONSE_CHARS: usize = 32_768;
pub(crate) const INITIALIZE_VERSION_MISMATCH_LOG: &str =
    "Client requested unsupported ACP protocol version; responding with v1";
pub(crate) const TOOL_READ_FILE_INVALID_INTEGER_TEMPLATE: &str =
    "Invalid {argument} value: expected a positive integer";
pub(crate) const TOOL_READ_FILE_INTEGER_RANGE_TEMPLATE: &str = "{argument} value exceeds the supported range";
pub(crate) const TOOL_READ_FILE_ABSOLUTE_PATH_TEMPLATE: &str = "Invalid {argument} value: expected an absolute path";
pub(crate) const TOOL_READ_FILE_WORKSPACE_ESCAPE_TEMPLATE: &str =
    "Invalid {argument} value: path escapes the trusted workspace";
pub(crate) const PLAN_STEP_ANALYZE: &str = "Review the latest user request and conversation context";
pub(crate) const PLAN_STEP_GATHER_CONTEXT: &str = "Gather referenced workspace files when required";
pub(crate) const PLAN_STEP_RESPOND: &str = "Compose and send the assistant response";
pub(crate) const WORKSPACE_TRUST_UPGRADE_LOG: &str = "ACP workspace trust level updated";
pub(crate) const WORKSPACE_TRUST_ALREADY_SATISFIED_LOG: &str = "ACP workspace trust level already satisfied";
pub(crate) const WORKSPACE_TRUST_DOWNGRADE_SKIPPED_LOG: &str =
    "ACP workspace trust downgrade skipped because workspace is fully trusted";
