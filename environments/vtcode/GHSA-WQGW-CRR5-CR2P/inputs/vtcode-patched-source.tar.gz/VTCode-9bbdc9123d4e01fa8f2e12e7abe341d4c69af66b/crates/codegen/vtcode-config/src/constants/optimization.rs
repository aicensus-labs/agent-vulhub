/// File read cache defaults (development and general use)
pub(crate) const FILE_READ_CACHE_MIN_SIZE_BYTES: usize = 256 * 1024; // 256 KB
pub(crate) const FILE_READ_CACHE_MAX_SIZE_BYTES: usize = 10 * 1024 * 1024; // 10 MB
pub(crate) const FILE_READ_CACHE_TTL_SECS: u64 = 300;
pub(crate) const FILE_READ_CACHE_MAX_ENTRIES: usize = 128;

/// Absolute ceiling on the number of lines a single `read_file` call may
/// return (line-based reads). Larger requests are clamped and the response
/// carries a `next_read_args` continuation so the agent can page forward.
pub const DEFAULT_MAX_READ_LINES: usize = 400;

/// File read cache defaults for production
pub(crate) const FILE_READ_CACHE_PROD_MIN_SIZE_BYTES: usize = 512 * 1024; // 512 KB
pub(crate) const FILE_READ_CACHE_PROD_MAX_SIZE_BYTES: usize = 25 * 1024 * 1024; // 25 MB
pub(crate) const FILE_READ_CACHE_PROD_TTL_SECS: u64 = 600;
pub(crate) const FILE_READ_CACHE_PROD_MAX_ENTRIES: usize = 256;

/// Command cache defaults (development and general use)
pub(crate) const COMMAND_CACHE_TTL_MS: u64 = 2_000;
pub(crate) const COMMAND_CACHE_MAX_ENTRIES: usize = 128;
pub(crate) const COMMAND_CACHE_ALLOWLIST: &[&str] = &["rg", "ls", "git status", "git diff --stat"];

/// Command cache defaults for production
pub(crate) const COMMAND_CACHE_PROD_TTL_MS: u64 = 3_000;
pub(crate) const COMMAND_CACHE_PROD_MAX_ENTRIES: usize = 256;
pub(crate) const COMMAND_CACHE_PROD_ALLOWLIST: &[&str] = &["rg", "ls", "git status", "git diff --stat"];
