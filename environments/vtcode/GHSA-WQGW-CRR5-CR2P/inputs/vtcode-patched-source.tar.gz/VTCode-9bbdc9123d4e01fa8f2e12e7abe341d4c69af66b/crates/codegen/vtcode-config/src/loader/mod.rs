#[cfg(feature = "bootstrap")]
mod bootstrap;
pub mod layers;
pub mod watch;

mod builder;
mod config;
mod fingerprint;
mod manager;
mod merge;
mod syntax_highlighting;

#[cfg(test)]
mod tests;

pub use builder::ConfigBuilder;
pub use config::{FeaturesConfig, ProviderConfig, VTCodeConfig, WorkspaceConfig};
pub use fingerprint::{fingerprint_str, fingerprint_toml_value};
pub use manager::{ConfigManager, ConfigPhaseTiming};
pub use merge::{merge_toml_values, merge_toml_values_with_origins};
pub use syntax_highlighting::SyntaxHighlightingConfig;
pub use watch::{ConfigWatcher, SimpleConfigWatcher};
