# vtcode-config
[Root AGENTS.md](../AGENTS.md) | Config loading, schema, constants. `vtcode.toml` is the source of truth.

## Modules

`loader/` ConfigManager + ConfigBuilder + layers | `constants/` models, env vars, URLs, tools, and shared tool limits | `core/` AgentConfig + all nested config structs | `models/` ModelId + Provider enums | `types/` ReasoningEffortLevel and related enums | `schema/` JSON Schema export (feature-gated) | `defaults/` ConfigDefaultsProvider | `auth/` auth config re-exports | `api_keys.rs` facade + `api_keys/credential_resolution.rs` source precedence | `mcp/` MCP config | `acp/` ACP config | `hooks/` lifecycle hooks | `subagents/` subagent discovery | `core/network_allowlist.rs` | `core/provider_override.rs`

## Rules

- `ModelId` enum is the canonical model identifier — all model matching must go through it.
- `constants/` is organized by domain: `models/`, `urls.rs`, `env_vars.rs`, `tools.rs`.
- `ConfigLayerStack` handles layered config (defaults → file → env → CLI) — do not bypass.
- `bootstrap` feature (default) scaffolds config dirs. Disable for parse-only consumers.
- `schema` feature gates `vtcode_config_schema_json()` — used by `build.rs`.
## Adding a Model

Two pathways: **OpenRouter** (code-generated) — edit `ModelId`, `Provider::OpenRouter` match, `docs/models.json`. Build script handles the rest. **Non-OpenRouter** (manual) — add constant, `ModelId` variant + all match arms, defaults if needed, preset, optional resolver update, `docs/models.json`. See `adding-llm-providers` skill for checklist.

## Gotchas

- `VTCodeConfig::load()` resolves layers — do not use `ConfigManager::load_from_workspace()` directly in production code.
- `models/model_id/table.rs` (`model_id_table!`) is the single source for as_str/parse/display/description/provider per variant — add new models as one table row, never a new match arm in the wrapper files.
- `parse.rs` keeps an order-sensitive hand-written preamble (opencode/evolink prefix routing, ZAI shadow guards, dated-haiku remap) before the table lookup — never move prefix rules into the table; NVIDIA's `z-ai/glm-5.2` picker variant intentionally has no bare parse entry because OpenRouter owns bare parsing.
- `core/automation.rs` holds the loop-engineering config surface: `LoopEngineConfig` (gated by `loop_engine_enabled()`, override with `VTCODE_DISABLE_LOOP_ENGINE`), and `verify_mutations` on `FullAutoConfig` — **default off** because the verifier sub-agent doubles mutating-call cost.
- `AgentHarnessConfig` now has `context_reset_mode` (`off`/`on_stall`/`on_compaction`) and `context_reset_stall_threshold` — distinct from compaction config. `event_log_path` is an explicit compatibility export; canonical events live in the workspace session store. Default reset mode: `off`.
- `constants::tool_limits` is the source of truth for execution-loop defaults, planning/approved-plan floors, and tool-loop extension caps; `agent.max_conversation_turns` remains context retention only.
- Token-efficiency defaults: `tool_result_clearing.enabled` defaults to `true` (old tool results stripped past `trigger_tokens`), `tools.client_tool_search` defaults to `true` (client-local deferral for providers without hosted tool search), and `agent.system_prompt_mode`/`tool_documentation_mode` stay `default`/`progressive`. When changing these, update `docs/config/CONFIG_FIELD_REFERENCE.md` and the guard-rail tests. `agent.ui_surface` defaults to `inline` so interactive plan/interview HITL overlays work without configuration; `auto` and `alternate` remain explicit overrides.
- Use `api_keys::resolve_credential_with_mode` for provider/key resolution so environment, workspace `.env`, OAuth, secure storage, and legacy migration share one precedence path. Use `get_api_key_with_mode` only for legacy string-returning callers and `provider_credential_detail_with_mode` for discovery summaries. Compatibility wrappers use the platform default storage mode.
- Custom provider profiles are exact model-ID overrides; keep `model`/`models` as the only allowlist and preserve explicit `false` capability values.
- Keep `ui.tool_display_mode` separate from `ui.tool_output_mode`; the former controls transition-summary grouping, while the latter controls tool output rendering. `timeouts.long_running_command_ceiling_seconds` bounds explicit session waits; update config docs and field-reference tables with timeout changes.
