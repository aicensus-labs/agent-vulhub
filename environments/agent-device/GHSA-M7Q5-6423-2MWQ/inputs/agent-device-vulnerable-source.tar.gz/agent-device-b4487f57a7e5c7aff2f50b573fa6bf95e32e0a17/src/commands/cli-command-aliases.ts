import type { CliFlags } from '../contracts/cli-flags.ts';

type BooleanCliFlagKey = {
  [Key in keyof CliFlags]-?: Exclude<CliFlags[Key], undefined> extends boolean ? Key : never;
}[keyof CliFlags];

export type CliCommandAlias = {
  alias: string;
  command: string;
  impliedFlags?: readonly BooleanCliFlagKey[];
};

const CLI_COMMAND_ALIASES: readonly CliCommandAlias[] = [
  { alias: 'long-press', command: 'longpress' },
  { alias: 'metrics', command: 'perf' },
  { alias: 'tap', command: 'press' },
  { alias: 'launch', command: 'open' },
  { alias: 'relaunch', command: 'open', impliedFlags: ['relaunch'] },
];

const aliasByToken: ReadonlyMap<string, CliCommandAlias> = new Map(
  CLI_COMMAND_ALIASES.map((entry) => [entry.alias, entry]),
);

export function normalizeCliCommandAlias(command: string): string {
  return aliasByToken.get(command.toLowerCase())?.command ?? command;
}

export function cliCommandAlias(rawCommand: string): CliCommandAlias | undefined {
  return aliasByToken.get(rawCommand.toLowerCase());
}

export function cliAliasesForCommand(command: string): CliCommandAlias[] {
  return CLI_COMMAND_ALIASES.filter((entry) => entry.command === command);
}
