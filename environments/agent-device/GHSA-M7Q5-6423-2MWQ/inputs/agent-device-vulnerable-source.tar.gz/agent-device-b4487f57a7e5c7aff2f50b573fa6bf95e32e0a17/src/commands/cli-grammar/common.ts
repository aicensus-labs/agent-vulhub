import type { InternalRequestOptions } from '../../contracts/client-request.ts';
import type { ElementTarget, InteractionTarget } from '../../contracts/client-target.ts';
import { splitSelectorFromArgs } from '../../selectors/parse.ts';
import {
  checkElementTargetArgs,
  checkGetFormat,
  SELECTOR_EXPRESSION_REQUIRED_MESSAGE,
} from '../../selectors/arguments.ts';
import type { CliFlags } from '../../contracts/cli-flags.ts';
import { AppError } from '../../kernel/errors.ts';
import { compactRecord, type SelectorSnapshotInput } from '../command-input.ts';
import type {
  DaemonWriter,
  SelectionOptions,
  DaemonCommandRequest,
  CommandInput,
} from './types.ts';

export function direct(
  command: string,
  positionals?: (input: CommandInput) => string[],
): DaemonWriter {
  return (input) => request(command, positionals ? positionals(input) : [], input);
}

export function request(
  command: string,
  positionals: string[],
  options: CommandInput,
  input?: Record<string, unknown>,
): DaemonCommandRequest {
  return {
    command,
    positionals,
    ...(input ? { input } : {}),
    options: normalizeCommonRequestOptions(options),
  };
}

function normalizeCommonRequestOptions(options: CommandInput): InternalRequestOptions {
  const normalizedTarget = readDeviceTarget(options.deviceTarget ?? options.target);
  if (normalizedTarget === undefined && options.target === undefined) {
    return options as InternalRequestOptions;
  }
  const { target: _target, ...rest } = options;
  return (
    normalizedTarget === undefined ? rest : { ...rest, target: normalizedTarget }
  ) as InternalRequestOptions;
}

function readDeviceTarget(value: unknown): InternalRequestOptions['target'] | undefined {
  return value === 'mobile' || value === 'tv' || value === 'desktop' ? value : undefined;
}

export function commonInputFromFlags(flags: CliFlags): Record<string, unknown> {
  return compactRecord({
    // `--no-record` is a COMMON flag (`COMMON_COMMAND_SUPPORTED_FLAG_KEYS`): it
    // is accepted on, and meaningful for, every recordable command. It rides
    // the common seam every reader already spreads, so a reader cannot forget
    // it and a new reader inherits it for free. The three seams it must survive
    // are this one, `readCommonInput`, and `commonToClientOptions`
    // (`commands/command-input.ts`) — a drop at any one of them silently
    // disables the flag (#1304/#1305 fixed only the reader layer, so the flag
    // still never reached the daemon).
    //
    // `--record` deliberately does NOT ride here: it is scoped to the
    // observation-only commands the repair-segment exclusion can drop
    // (ADR 0012 decision 6 amendment), so it stays on the narrow
    // `observationRecordInputFromFlags` seam below.
    noRecord: flags.noRecord,
    session: flags.session,
    platform: flags.platform,
    deviceTarget: flags.target,
    device: flags.device,
    udid: flags.udid,
    serial: flags.serial,
    iosSimulatorDeviceSet: flags.iosSimulatorDeviceSet,
    iosXctestrunFile: flags.iosXctestrunFile,
    iosXctestDerivedDataPath: flags.iosXctestDerivedDataPath,
    iosXctestEnvDir: flags.iosXctestEnvDir,
    androidDeviceAllowlist: flags.androidDeviceAllowlist,
  });
}

/**
 * #1271 stage 2 (ADR 0012 decision 6 amendment): the `--record` opt-in that
 * forces an observation-only action into a repair-armed heal. Spread ONLY by
 * readers whose command can be excluded by default — `snapshot`, `get`, `is`,
 * and `find`. Every one of those readers must ALSO spread
 * the common `commonInputFromFlags` seam, which carries `--no-record` for every
 * recordable command, mutations included.
 */
export function observationRecordInputFromFlags(flags: CliFlags): Record<string, unknown> {
  return compactRecord({
    record: flags.record,
  });
}

/**
 * The reader layer has TWO parallel common seams, not one: this builds the
 * client-options shape (`target`) for readers that construct a typed Options
 * object directly (`is`/`find`/`wait`/`settings`), while `commonInputFromFlags`
 * above builds the reader-input shape (`deviceTarget`). They are different
 * projections, not duplicates — so `--no-record` has to ride BOTH or the
 * readers using this one silently drop it (which is what #1304/#1305's
 * per-reader helper was papering over).
 */
export function selectionOptionsFromFlags(flags: CliFlags): SelectionOptions {
  return {
    noRecord: flags.noRecord,
    platform: flags.platform,
    target: flags.target,
    device: flags.device,
    udid: flags.udid,
    serial: flags.serial,
    iosSimulatorDeviceSet: flags.iosSimulatorDeviceSet,
    androidDeviceAllowlist: flags.androidDeviceAllowlist,
  };
}

export function selectorSnapshotInputFromFlags(flags: CliFlags): Record<string, unknown> {
  return compactRecord({
    depth: flags.snapshotDepth,
    scope: flags.snapshotScope,
    raw: flags.snapshotRaw,
  });
}

export function selectorSnapshotOptionsFromFlags(flags: CliFlags): SelectorSnapshotInput {
  return {
    depth: flags.snapshotDepth,
    scope: flags.snapshotScope,
    raw: flags.snapshotRaw,
  };
}

// Descriptor post-action observation commands use --settle (#1101).
// --timeout doubles as the settle deadline only when --settle is present; a
// bare --timeout stays compatible and is ignored by touch commands.
export function settleInputFromFlags(flags: CliFlags): Record<string, unknown> {
  return compactRecord({
    settle: flags.settle,
    settleQuietMs: flags.settleQuietMs,
    timeoutMs: flags.timeoutMs,
  });
}

export function repeatedInputFromFlags(flags: CliFlags): Record<string, unknown> {
  return compactRecord({
    count: flags.count,
    intervalMs: flags.intervalMs,
    holdMs: flags.holdMs,
    jitterPx: flags.jitterPx,
    doubleTap: flags.doubleTap,
  });
}

export function targetInputFromClientTarget(
  target: InteractionTarget | ElementTarget,
): Record<string, unknown> {
  if ('ref' in target && target.ref !== undefined) {
    return compactRecord({ kind: 'ref', ref: target.ref, label: target.label });
  }
  if ('selector' in target && target.selector !== undefined) {
    return { kind: 'selector', selector: target.selector };
  }
  const point = target as { x: number; y: number };
  return { kind: 'point', x: point.x, y: point.y };
}

export function interactionTargetPositionals(input: InteractionTarget | CommandInput): string[] {
  const target = readTargetRecord(input);
  if (typeof target.ref === 'string') return [target.ref, ...optionalTargetLabel(target.label)];
  if (typeof target.selector === 'string') return [target.selector];
  if (target.kind === 'point' || target.x !== undefined || target.y !== undefined) {
    return [
      String(requiredTargetNumber(target.x, 'x')),
      String(requiredTargetNumber(target.y, 'y')),
    ];
  }
  throw new AppError('INVALID_ARGS', 'interaction requires @ref, selector, or point target');
}

export function elementTargetPositionals(input: ElementTarget | CommandInput): string[] {
  const target = readTargetRecord(input);
  if (typeof target.ref === 'string') return [target.ref, ...optionalTargetLabel(target.label)];
  if (typeof target.selector === 'string') return [target.selector];
  throw new AppError('INVALID_ARGS', 'element command requires @ref or selector target');
}

function readTargetRecord(input: unknown): Record<string, unknown> {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new AppError('INVALID_ARGS', 'Expected target object.');
  }
  const record = input as Record<string, unknown>;
  const nestedTarget = record.target;
  if (nestedTarget && typeof nestedTarget === 'object' && !Array.isArray(nestedTarget)) {
    return nestedTarget as Record<string, unknown>;
  }
  return record;
}

function requiredTargetNumber(value: unknown, field: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new AppError('INVALID_ARGS', `point target requires numeric ${field}.`);
  }
  return value;
}

function optionalTargetLabel(value: unknown): string[] {
  return typeof value === 'string' && value.length > 0 ? [value] : [];
}

export function readElementTargetFromPositionals(positionals: string[]): ElementTarget {
  const target = checkElementTargetArgs(positionals);
  if (!target.ok) throw new AppError(target.code, target.message);
  if ('ref' in target) {
    return { ref: target.ref, label: optionalTrimmedText(positionals.slice(1)) };
  }
  return { selector: target.selector };
}

export function readGetFormat(value: string | undefined): 'text' | 'attrs' {
  const checked = checkGetFormat(value);
  if (!checked.ok) throw new AppError(checked.code, checked.message);
  return checked.format;
}

export function splitRequiredSelector(
  positionals: string[],
  options: { preferTrailingValue?: boolean } = {},
) {
  const split = splitSelectorFromArgs(positionals, options);
  // Shares `is`'s refusal with the daemon, which reaches it through checkIsArgs.
  if (!split) throw new AppError('INVALID_ARGS', SELECTOR_EXPRESSION_REQUIRED_MESSAGE);
  return split;
}

export function readJsonObject(value: string, label: string): Record<string, unknown> {
  try {
    const parsed = JSON.parse(value) as unknown;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>;
    }
  } catch {}
  throw new AppError('INVALID_ARGS', `${label} must be a JSON object`);
}

function optionalTrimmedText(values: string[]): string | undefined {
  const text = values.join(' ').trim();
  return text || undefined;
}

export function setOf<T extends string>(...values: T[]): ReadonlySet<T> {
  return new Set(values);
}

export function isOneOf<T extends string>(
  value: string | undefined,
  values: ReadonlySet<T>,
): value is T {
  return value !== undefined && values.has(value as T);
}

export function isFiniteNumberString(value: string | undefined): boolean {
  if (value === undefined || value.trim() === '') return false;
  return Number.isFinite(Number(value));
}

export function readFiniteNumber(value: string | undefined, label: string): number | undefined {
  if (value === undefined) return undefined;
  const parsed = Number(value);
  if (Number.isFinite(parsed)) return parsed;
  throw new AppError('INVALID_ARGS', `${label} must be a finite number.`);
}

export function optionalCliNumber(value: string | undefined): number | undefined {
  return value === undefined ? undefined : Number(value);
}

export function optionalString(value: string | undefined): string[] {
  return value === undefined ? [] : [value];
}

export function optionalNumber(value: number | undefined): string[] {
  return value === undefined ? [] : [String(value)];
}

export function requiredString(value: string | undefined, message: string): string {
  if (value === undefined || value === '') throw new AppError('INVALID_ARGS', message);
  return value;
}

export function requiredDaemonString(value: unknown, message: string): string {
  if (typeof value !== 'string' || value.length === 0) {
    throw new AppError('INVALID_ARGS', message);
  }
  return value;
}
